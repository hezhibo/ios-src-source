//
//  customDeleteButton.h
//  MultiRow
//
//  Created by Jonah on 11-04-27.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface customDeleteButton : UITableViewCell {

}

@end
