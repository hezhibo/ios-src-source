//
//  MultiRowViewController.h
//  MultiRow
//
//  Created by Jonah on 11-04-26.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "customDeleteButton.h"


@interface MultiRowViewController : UIViewController <UITableViewDelegate, UITableViewDataSource> {



}

@end

