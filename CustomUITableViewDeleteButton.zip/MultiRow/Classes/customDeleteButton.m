//
//  customDeleteButton.m
//  MultiRow
//
//  Created by Jonah on 11-04-27.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "customDeleteButton.h"


@implementation customDeleteButton

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code.
    }
    return self;
}

- (void)willTransitionToState:(UITableViewCellStateMask)state{

	[super willTransitionToState:state];

	
if ((state & UITableViewCellStateShowingDeleteConfirmationMask) == UITableViewCellStateShowingDeleteConfirmationMask) {
	
	
	for (UIView *subview in self.subviews) {
			
		if ([NSStringFromClass([subview class]) isEqualToString:@"UITableViewCellDeleteConfirmationControl"]) {             
			
			
			
			UIImageView *deleteBtn = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, 64, 33)];
			[deleteBtn setImage:[UIImage imageNamed:@"delete.png"]];
			[[subview.subviews objectAtIndex:0] addSubview:deleteBtn];
			[deleteBtn release];
			
			
		
			
		}
		
		
	}
  } 
	
}


- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state.
}


- (void)dealloc {
    [super dealloc];
}


@end
