//
//  MultiRowAppDelegate.h
//  MultiRow
//
//  Created by Jonah on 11-04-26.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@class MultiRowViewController;

@interface MultiRowAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
    MultiRowViewController *viewController;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet MultiRowViewController *viewController;

@end

