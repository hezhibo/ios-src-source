//
//  MainViewController.h
//  amrDemoForiOS
//
//  Created by Tang Xiaoping on 9/23/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "FlipsideViewController.h"

@interface MainViewController : UIViewController <FlipsideViewControllerDelegate> {

}


- (IBAction)showInfo:(id)sender;

@end
