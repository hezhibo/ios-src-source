//
//  amrDemoForiOSTests.h
//  amrDemoForiOSTests
//
//  Created by Tang Xiaoping on 9/23/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>


@interface amrDemoForiOSTests : SenTestCase {
@private
    
}

@end
