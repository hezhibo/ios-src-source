//
//  ViewController.m
//  ScrollableBackgroundTableView
//
//  Created by Haven Tang on 12-3-28.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "ViewController.h"

@implementation ViewController
@synthesize scrollBgTableView;

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle



- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    
   
    scrollBgTableView.backgroundColor = [UIColor clearColor];
    scrollBgTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    
    [self.scrollBgTableView setContentInset:UIEdgeInsetsMake(50,0,0,0)];
    
    
    [self.scrollBgTableView layoutIfNeeded];
    
    
    CALayer *bgLayer = [CALayer layer];  
    bgLayer.contents = (id)[UIImage imageNamed:@"bg.jpg"].CGImage;  
    bgLayer.anchorPoint = CGPointZero;  
    bgLayer.bounds = CGRectMake(0, 0,  
                                320 ,  
                                480);  
    CGRect rect = bgLayer.frame;  
    rect.origin.y = -50;  
    bgLayer.frame = rect;  
    
    [self.scrollBgTableView.layer addSublayer:bgLayer];  
    bgLayer.zPosition = -5; //这一句一定要，数值得小于0都可以  
}

- (void)viewDidUnload
{
    [self setScrollBgTableView:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

- (void)dealloc {
    [scrollBgTableView release];
    [super dealloc];
}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
//    [CATransaction begin];
//    [CATransaction setDisableActions:YES];
//    maskLayer.position = CGPointMake(0, scrollView.contentOffset.y);
//    [CATransaction commit];
}

#pragma mark - UITableViewDataSource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 5;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{

    static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];
        //cell.backgroundColor = [UIColor clearColor];
        //cell.backgroundView = nil;
        //cell.selectedBackgroundView = [[[UIImageView alloc] init] autorelease];
    }
    
//    UIImageView *bgView = (UIImageView *)[cell selectedBackgroundView];
//    if (indexPath.row == 0) {
//        bgView.image = [UIImage imageNamed:@"cell-selected-top"];
//    }
//    else if (indexPath.row == 4)
//    {
//        bgView.image = [UIImage imageNamed:@"cell-selected-bottom"];
//    }
//    else
//    {
//        bgView.image = [UIImage imageNamed:@"cell-selected-middle"];
//    }
    
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    cell.textLabel.text = @"normal cell";
    return cell;
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{
    return @" ";
}

@end
