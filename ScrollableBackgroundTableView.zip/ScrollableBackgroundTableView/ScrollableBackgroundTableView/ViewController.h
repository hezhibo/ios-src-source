//
//  ViewController.h
//  ScrollableBackgroundTableView
//
//  Created by Haven Tang on 12-3-28.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>

@interface ViewController : UIViewController<UITableViewDelegate, UITableViewDataSource>
{
    CAGradientLayer *maskLayer;
}
@property (retain, nonatomic) IBOutlet UITableView *scrollBgTableView;

@end
