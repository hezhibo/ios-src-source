//
//  GisDrawLineTestViewController.m
//  GisDrawLineTest
//
//  Created by Yang on 2/14/11.
//  Copyright __MyCompanyName__ 2011. All rights reserved.
//

#import "GisDrawLineTestViewController.h"

@implementation GisDrawLineTestViewController

@synthesize mapView=_mapView;
@synthesize drawLineLayer; 

/*
// The designated initializer. Override to perform setup that is required before the view is loaded.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
        // Custom initialization
    }
    return self;
}
*/

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView {
}
*/



// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	
	selectedMapPoints = [[NSMutableArray alloc] init];
	
	/* ##################################################### */
	// TODO
	// Replace the following block of code with your own.
	//
	self.mapView.touchDelegate = self;
	NSURL *mapUrl = [NSURL URLWithString:@"http://services.arcgisonline.com/ArcGIS/rest/services/World_Street_Map/MapServer"];
	AGSTiledMapServiceLayer *tiledLyr = [AGSTiledMapServiceLayer tiledMapServiceLayerWithURL:mapUrl];
	[self.mapView addMapLayer:tiledLyr withName:@"Tiled Layer"];
	
	AGSSpatialReference *sr = [AGSSpatialReference spatialReferenceWithWKID:102100];
	AGSEnvelope *env = [AGSEnvelope envelopeWithXmin:-13626513.829723023 
												ymin:4549088.827634182 
												xmax:-13626131.64458163 
												ymax:4549638.218774935 
									spatialReference:sr];
	[self.mapView zoomToEnvelope:env animated:YES];
	
	self.drawLineLayer = [AGSGraphicsLayer graphicsLayer];
	[self.mapView addMapLayer:self.drawLineLayer withName:@"DrawLineLayer"];
	
	/* ##################################################### */
}



/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
	
	// Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
	// Release any retained subviews of the main view.
	// e.g. self.myOutlet = nil;
}


- (void)dealloc {
	self.mapView = nil;
    [super dealloc];
}

#pragma mark AGSMapViewDelegate
- (void)mapView:(AGSMapView *) mapView didClickAtPoint:(CGPoint) screen mapPoint:(AGSPoint *) mappoint graphics:(NSDictionary *) graphics {
    NSArray *gArray = [graphics objectForKey:@"DrawLineLayer"];
	AGSSimpleMarkerSymbol* myMarkerSymbol = [AGSSimpleMarkerSymbol simpleMarkerSymbol];
	myMarkerSymbol.color = [UIColor blueColor];
	myMarkerSymbol.style = AGSSimpleMarkerSymbolStyleCircle;
	myMarkerSymbol.outline.color = [UIColor redColor];
	myMarkerSymbol.outline.width = 0;
	NSLog(@"mappoint is %@", mappoint);
	AGSGraphic *pointGraphic = [[AGSGraphic alloc] initWithGeometry:mappoint symbol:myMarkerSymbol attributes:nil infoTemplateDelegate:nil];
	[self.drawLineLayer addGraphic:pointGraphic];
	[pointGraphic release];
	[self.drawLineLayer dataChanged];
	[selectedMapPoints addObject:mappoint];
	int count = [selectedMapPoints count];
	if ( count> 1) {
	
			AGSMutablePolyline *polyLine = [[AGSMutablePolyline alloc] initWithSpatialReference:nil];
			[polyLine addPathToPolyline];
			for (int i = 0; i < count; i++) {
			[polyLine addPointToPath:[selectedMapPoints objectAtIndex:i]];
			}
			//[polyLine addPathToPolyline];
			//[polyLine addPointToPath:[selectedMapPoints objectAtIndex:i]];
			AGSSimpleLineSymbol* myOutlineSymbol = [AGSSimpleLineSymbol simpleLineSymbol];
			myOutlineSymbol.color = [UIColor redColor];
			myOutlineSymbol.width = 10;
			myOutlineSymbol.style = AGSSimpleLineSymbolStyleSolid;
			AGSGraphic *graphic = [[AGSGraphic alloc] initWithGeometry:polyLine
																symbol:myOutlineSymbol 
															attributes:nil infoTemplateDelegate:nil];
			
			[self.drawLineLayer addGraphic:graphic];
			[graphic release];
			[self.drawLineLayer dataChanged];
			
		//}
		}
}



@end
