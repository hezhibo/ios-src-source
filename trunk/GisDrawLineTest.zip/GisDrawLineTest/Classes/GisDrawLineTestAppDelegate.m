//
//  GisDrawLineTestAppDelegate.m
//  GisDrawLineTest
//
//  Created by Yang on 2/14/11.
//  Copyright __MyCompanyName__ 2011. All rights reserved.
//

#import "GisDrawLineTestAppDelegate.h"
#import "GisDrawLineTestViewController.h"

@implementation GisDrawLineTestAppDelegate

@synthesize window;
@synthesize viewController;


- (void)applicationDidFinishLaunching:(UIApplication *)application {    
    
    // Override point for customization after app launch    
    [window addSubview:viewController.view];
    [window makeKeyAndVisible];
}


- (void)dealloc {
    [viewController release];
    [window release];
    [super dealloc];
}


@end
