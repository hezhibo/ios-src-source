//
//  GisDrawLineTestViewController.h
//  GisDrawLineTest
//
//  Created by Yang on 2/14/11.
//  Copyright __MyCompanyName__ 2011. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ArcGIS.h"

@interface GisDrawLineTestViewController : UIViewController<AGSMapViewLayerDelegate, AGSMapViewCalloutDelegate, AGSMapViewTouchDelegate> {
	AGSMapView *_mapView;
	AGSGraphicsLayer *drawLineLayer;
	NSMutableArray *selectedMapPoints;
	
}


@property (nonatomic, retain) IBOutlet AGSMapView *mapView;
@property(nonatomic,retain)AGSGraphicsLayer *drawLineLayer;

@end

