//
//  GisDrawLineTestAppDelegate.h
//  GisDrawLineTest
//
//  Created by Yang on 2/14/11.
//  Copyright __MyCompanyName__ 2011. All rights reserved.
//

#import <UIKit/UIKit.h>

@class GisDrawLineTestViewController;

@interface GisDrawLineTestAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
    GisDrawLineTestViewController *viewController;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet GisDrawLineTestViewController *viewController;

@end

