//
//  ViewController.h
//  BASequenceControlDemo
//
//  Created by Guo Muchuan on 11/22/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BASequenceControl.h"

@interface ViewController : UIViewController
{
	BASequenceControl *basc;
}

@property (nonatomic, retain) IBOutlet BASequenceControl *basc;
@end
