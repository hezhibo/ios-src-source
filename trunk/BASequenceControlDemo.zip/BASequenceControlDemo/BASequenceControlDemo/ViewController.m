//
//  ViewController.m
//  BASequenceControlDemo
//
//  Created by Guo Muchuan on 11/22/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import "ViewController.h"

@implementation ViewController
@synthesize basc;

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}

- (void)dealloc
{
	self.basc = nil;
	
}

#pragma mark - View lifecycle

- (void)valueDidChange {
	NSString *str = [self.basc titleForSegmentAtIndex:self.basc.selectedSegmentIndex];
	NSLog(@"str=%@",str);
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
	
	//basc = [[BASequenceControl alloc] initWithFrame:CGRectMake(0, 0, 320, 44)];
	[basc addSegmentWithTitle:@"One" animated:NO];
    [basc addSegmentWithTitle:@"Two" animated:NO];
    [basc addSegmentWithTitle:@"Three" animated:NO];   
	basc.leftMargin = 10;
	basc.rightMargin = 10;
	basc.overlapWidth = 22;
	[self.basc addTarget:self action:@selector(valueDidChange) forControlEvents:UIControlEventValueChanged];
	
	BASequenceControl *bs1 = [[BASequenceControl alloc] initWithFrame:CGRectMake(0, 80, 320, 44)];
	[bs1 addSegmentWithTitle:@"happy" animated:NO];
	[bs1 addSegmentWithTitle:@"good" animated:NO];
	[bs1 addSegmentWithTitle:@"cool" animated:NO];
	bs1.overlapWidth = 22;
	[self.view addSubview:bs1];
	[bs1 release];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
	self.basc = nil;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
	[super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
	[super viewDidDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
	return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

@end
