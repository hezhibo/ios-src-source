//
//  ReplicatorDemoiPadAppDelegate.h
//  ReplicatorDemoiPad
//
//  Created by Brad Larson on 4/24/2010.
//
//  This is simply an iPad port of Apple's Replicator Demo Mac sample:
//  http://developer.apple.com/mac/library/samplecode/ReplicatorDemo/Introduction/Intro.html


#import <UIKit/UIKit.h>

@class ReplicatorDemoiPadViewController;

@interface ReplicatorDemoiPadAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
    ReplicatorDemoiPadViewController *viewController;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet ReplicatorDemoiPadViewController *viewController;

@end

