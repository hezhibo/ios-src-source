//
//  ReplicatorDemoiPadAppDelegate.m
//  ReplicatorDemoiPad
//
//  Created by Brad Larson on 4/24/2010.
//
//  This is simply an iPad port of Apple's Replicator Demo Mac sample:
//  http://developer.apple.com/mac/library/samplecode/ReplicatorDemo/Introduction/Intro.html

#import "ReplicatorDemoiPadAppDelegate.h"
#import "ReplicatorDemoiPadViewController.h"

@implementation ReplicatorDemoiPadAppDelegate

@synthesize window;
@synthesize viewController;


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {    
    
    // Override point for customization after app launch    
    [window addSubview:viewController.view];
    [window makeKeyAndVisible];

	return YES;
}


- (void)dealloc {
    [viewController release];
    [window release];
    [super dealloc];
}


@end
