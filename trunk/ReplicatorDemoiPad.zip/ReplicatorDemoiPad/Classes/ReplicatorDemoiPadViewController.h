//
//  ReplicatorDemoiPadViewController.h
//  ReplicatorDemoiPad
//
//  Created by Brad Larson on 4/24/2010.
//
//  This is simply an iPad port of Apple's Replicator Demo Mac sample:
//  http://developer.apple.com/mac/library/samplecode/ReplicatorDemo/Introduction/Intro.html

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>

@interface ReplicatorDemoiPadViewController : UIViewController 
{
	CALayer *rootLayer;
	CAReplicatorLayer *replicatorX;
	CAReplicatorLayer *replicatorY;
	CAReplicatorLayer *replicatorZ;
	
	CALayer *subLayer;	
}

//Animates the layers by having them rotate and fly past the camera.
-(void)animate:(id)sender;

//Animate the layers back into the original cube formation
-(void)reset:(id)sender;

//Activtes each replicator one by one using timers to control when each starts
// (Used for the intro sequnce where a single layer expands into the 3D cube)
-(void)addOffests:(id)sender;

//Activtes the X replicator by settign its instance count and instance transform
// (Used for the intro sequnce where a single layer expands into the 3D cube)
-(void)addXReplicator:(id)sender;

//Activtes the Y replicator by settign its instance count and instance transform
// (Used for the intro sequnce where a single layer expands into the 3D cube)
-(void)addYReplicator:(id)sender;

//Activtes the Z replicator by settign its instance count and instance transform
// (Used for the intro sequnce where a single layer expands into the 3D cube)
-(void)addZReplicator:(id)sender;


@end

